import express from "express";
import cors from "cors";
import bodyParser from "body-parser";
import { db } from "./database.js";

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors({ origin: "*" }));
app.use(bodyParser.json());

app.get("/", (req, res) => {
  res.send("FLISS BACKEND OK");
});

app.get("/api/users", async (req, res) => {
  try {
    const users = await db.all(
      "SELECT id, email, role, agency FROM users ORDER BY id DESC"
    );
    res.json({ ok: true, users });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

app.post("/api/users", async (req, res) => {
  const { email, password, role = "user", agency = "" } = req.body;

  if (!email || !password) {
    return res.status(400).json({ ok: false, error: "email et password requis" });
  }

  try {
    await db.run(
      "INSERT INTO users (email, password, role, agency) VALUES (?, ?, ?, ?)",
      [email, password, role, agency]
    );
    res.json({ ok: true });
  } catch (e) {
    if (e.message.includes("UNIQUE")) {
      return res.status(409).json({ ok: false, error: "Utilisateur déjà existant" });
    }
    res.status(500).json({ ok: false, error: e.message });
  }
});

app.post("/api/login", async (req, res) => {
  const { email, password } = req.body;

  const user = await db.get(
    "SELECT id, email, role, agency FROM users WHERE email = ? AND password = ?",
    [email, password]
  );

  if (!user) {
    return res.status(401).json({ ok: false, error: "Login invalide" });
  }

  res.json({ ok: true, user });
});

app.listen(PORT, () => {
  console.log("🚀 Backend Fliss démarré sur port", PORT);
});
